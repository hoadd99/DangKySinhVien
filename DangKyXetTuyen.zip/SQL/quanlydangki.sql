create database Quanlydangky
go
use Quanlydangky
go
create table users(
	taikhoan nvarchar(50),
	matkhau varchar(50)
)

insert into users (taikhoan,matkhau)values('doduchoa200499','hoado200499')
insert into users (taikhoan,matkhau)values('doduchoa@gmail.com','hoado200499')
insert into users (taikhoan,matkhau)values('hoado200499','hoado200499')
go
create table thongtincanhan(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	hoten nvarchar(50),
	ngaysinh smalldatetime,
	gioitinh nchar(3),
	ykien nvarchar(200),
	camket bit,
	dcbaotin nvarchar(100)
)
go

create table xacnhanthongtin(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	cmmd int,
	noicap nvarchar(100),
	ngaycap smalldatetime,
	hkthuongtru nvarchar(100),
	sdt int,
	email nvarchar(50)
)
go

create table nghanhxt(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	nguyenvong1 nvarchar(200),
	khoixt1 nvarchar(5),
	nguyenvong2 nvarchar(200),
	khoixt2 nvarchar(5)
)
go
create table phuongthuc(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	diemhocba nvarchar(50),
	diemthi nvarchar(50),
	cahai nchar(10)
)
go

create table thuocdien(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	douutien nvarchar(200),
	khuvuc nvarchar(50)
)
go

create table hosokemtheo(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	hocba text,
	vanbang text,
	hinh text
)
go

create table truonghoc(
	tentruong nvarchar(200),
	lop int PRIMARY KEY,
	matinh nvarchar(20),
	matruong nvarchar(20)
)
go
create table ketqua(
	masv INT IDENTITY(1,1) NOT NULL,
	lop int NOT NULL,
	tenmonhoc nvarchar(50) NOT NULL,
	diem int NOT NULL,
	hanhkiem nvarchar(10) NOT NULL
	CONSTRAINT pk_ketqua1 PRIMARY KEY (lop,tenmonhoc,masv)
)
go
create table diemquocgia(
	masv INT IDENTITY(1,1) PRIMARY KEY,
	tenmonhoc nvarchar(50) NOT NULL,
	diem int NOT NULL,
	hanhkiem nvarchar(10) NOT NULL
)


ALTER TABLE thuocdien ADD CONSTRAINT fk_thuocdien FOREIGN KEY (masv) REFERENCES thongtincanhan (masv);
ALTER TABLE phuongthuc ADD CONSTRAINT fk_phuongthuc FOREIGN KEY (masv) REFERENCES thongtincanhan (masv);
ALTER TABLE xacnhanthongtin ADD CONSTRAINT fk_xacnhanthongtin FOREIGN KEY (masv) REFERENCES thongtincanhan (masv);
ALTER TABLE nghanhxt ADD CONSTRAINT fk_nghanhxt FOREIGN KEY (masv) REFERENCES thongtincanhan (masv);
ALTER TABLE hosokemtheo ADD CONSTRAINT fk_hosokemtheo FOREIGN KEY (masv) REFERENCES thongtincanhan (masv);

ALTER TABLE ketqua ADD CONSTRAINT fk_ketqua_truonghoc FOREIGN KEY (lop) REFERENCES truonghoc (lop);
ALTER TABLE ketqua ADD CONSTRAINT fk_ketqua_monhoc FOREIGN KEY (tenmonhoc) REFERENCES  monhoc(tenmonhoc);
ALTER TABLE ketqua ADD CONSTRAINT fk_ketqua_thongtincanhan FOREIGN KEY (masv) REFERENCES  thongtincanhan(masv);
