﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoDucHoa
{
    public partial class fQuanly : Form
    {
        public fQuanly()
        {
            InitializeComponent();
        }

        private void btTroLaiQL_Click(object sender, EventArgs e)
        {
            fGioithieu gt = new fGioithieu();
            gt.Show();
            this.Close();
        }
    }
}
