﻿namespace DoDucHoa
{
    partial class fThongtin2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbbKhoi_XT2 = new System.Windows.Forms.ComboBox();
            this.cbbKhoi_XT1 = new System.Windows.Forms.ComboBox();
            this.cbbNguyenVong2 = new System.Windows.Forms.ComboBox();
            this.cbbNguyenVong1 = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btTiepTuc = new System.Windows.Forms.Button();
            this.btTroLai = new System.Windows.Forms.Button();
            this.btChon1 = new System.Windows.Forms.Button();
            this.btChon2 = new System.Windows.Forms.Button();
            this.btChon3 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.ptbVanBang = new System.Windows.Forms.PictureBox();
            this.ptbHinh = new System.Windows.Forms.PictureBox();
            this.ptbHocBa = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ptbVanBang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbHinh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbHocBa)).BeginInit();
            this.SuspendLayout();
            // 
            // cbbKhoi_XT2
            // 
            this.cbbKhoi_XT2.FormattingEnabled = true;
            this.cbbKhoi_XT2.Items.AddRange(new object[] {
            "A",
            "A1",
            "B",
            "D1"});
            this.cbbKhoi_XT2.Location = new System.Drawing.Point(473, 63);
            this.cbbKhoi_XT2.Name = "cbbKhoi_XT2";
            this.cbbKhoi_XT2.Size = new System.Drawing.Size(108, 21);
            this.cbbKhoi_XT2.TabIndex = 345;
            // 
            // cbbKhoi_XT1
            // 
            this.cbbKhoi_XT1.FormattingEnabled = true;
            this.cbbKhoi_XT1.Items.AddRange(new object[] {
            "A",
            "A1",
            "B",
            "D1"});
            this.cbbKhoi_XT1.Location = new System.Drawing.Point(473, 36);
            this.cbbKhoi_XT1.Name = "cbbKhoi_XT1";
            this.cbbKhoi_XT1.Size = new System.Drawing.Size(108, 21);
            this.cbbKhoi_XT1.TabIndex = 344;
            // 
            // cbbNguyenVong2
            // 
            this.cbbNguyenVong2.FormattingEnabled = true;
            this.cbbNguyenVong2.Items.AddRange(new object[] {
            "Chọn ngành xét tuyển",
            "Công nghệ kỹ thuật ô tô",
            "Tài chính ngân hàng",
            "Đầu Tư Tài Chính",
            "Quản trị khách sạn",
            "Quản trị nhà hàng và dịch vụ ăn uống",
            "Quản trị kinh doanh tổng hợp",
            "Kế toán",
            "Công nghệ kỹ thuật cơ khí",
            "Công nghệ chế tạo máy",
            "Công nghệ kỹ thuật cơ điện tử",
            "Công nghệ may",
            "Công nghệ sợi dệt",
            "Công nghệ da giày",
            "Chuyên ngành Hóa hữu cơ",
            "Công nghệ giấy và bột giấy",
            "Công nghệ nhuộm",
            "Công nghệ thực phẩm",
            "Ngành phân tích kiểm nghiệm",
            "Công nghệ thông tin",
            "Quản trị mạng máy tính",
            "Chuyên ngành công nghệ nhiệt lạnh",
            "Chuyên ngành điện công nghiệp",
            "Chuyên ngành điện tử công nghiệp",
            "Công nghệ kỹ thuật điện tử, truyền thông",
            "Chuyên ngành kỹ thuật điều khiển và tự động hóa",
            "Tiếng anh thương mại",
            "QUẢN TRỊ KINH DOANH XUẤT NHẬP KHẨU"});
            this.cbbNguyenVong2.Location = new System.Drawing.Point(131, 63);
            this.cbbNguyenVong2.Name = "cbbNguyenVong2";
            this.cbbNguyenVong2.Size = new System.Drawing.Size(280, 21);
            this.cbbNguyenVong2.TabIndex = 343;
            // 
            // cbbNguyenVong1
            // 
            this.cbbNguyenVong1.FormattingEnabled = true;
            this.cbbNguyenVong1.Items.AddRange(new object[] {
            "Chọn ngành xét tuyển",
            "Công nghệ kỹ thuật ô tô",
            "Tài chính ngân hàng",
            "Đầu Tư Tài Chính",
            "Quản trị khách sạn",
            "Quản trị nhà hàng và dịch vụ ăn uống",
            "Quản trị kinh doanh tổng hợp",
            "Kế toán",
            "Công nghệ kỹ thuật cơ khí",
            "Công nghệ chế tạo máy",
            "Công nghệ kỹ thuật cơ điện tử",
            "Công nghệ may",
            "Công nghệ sợi dệt",
            "Công nghệ da giày",
            "Chuyên ngành Hóa hữu cơ",
            "Công nghệ giấy và bột giấy",
            "Công nghệ nhuộm",
            "Công nghệ thực phẩm",
            "Ngành phân tích kiểm nghiệm",
            "Công nghệ thông tin",
            "Quản trị mạng máy tính",
            "Chuyên ngành công nghệ nhiệt lạnh",
            "Chuyên ngành điện công nghiệp",
            "Chuyên ngành điện tử công nghiệp",
            "Công nghệ kỹ thuật điện tử, truyền thông",
            "Chuyên ngành kỹ thuật điều khiển và tự động hóa",
            "Tiếng anh thương mại",
            "QUẢN TRỊ KINH DOANH XUẤT NHẬP KHẨU"});
            this.cbbNguyenVong1.Location = new System.Drawing.Point(131, 36);
            this.cbbNguyenVong1.Name = "cbbNguyenVong1";
            this.cbbNguyenVong1.Size = new System.Drawing.Size(280, 21);
            this.cbbNguyenVong1.TabIndex = 342;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(422, 39);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(45, 13);
            this.label31.TabIndex = 341;
            this.label31.Text = "Khối XT";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(45, 70);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(80, 13);
            this.label30.TabIndex = 340;
            this.label30.Text = "Nguyện vọng 2";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(422, 71);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 13);
            this.label29.TabIndex = 339;
            this.label29.Text = "Khối XT";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(45, 39);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(80, 13);
            this.label28.TabIndex = 338;
            this.label28.Text = "Nguyện vọng 1";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(13, 10);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(126, 13);
            this.label27.TabIndex = 337;
            this.label27.Text = "Ngành đăng kí xét tuyển";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(408, 227);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(94, 13);
            this.label53.TabIndex = 396;
            this.label53.Text = "Bản sao văn bằng";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(257, 227);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(29, 13);
            this.label52.TabIndex = 395;
            this.label52.Text = "Hình";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(50, 227);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(42, 13);
            this.label49.TabIndex = 394;
            this.label49.Text = "Học bạ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(505, 110);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 13);
            this.label26.TabIndex = 447;
            this.label26.Text = "Mã trương";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(397, 113);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(42, 13);
            this.label25.TabIndex = 446;
            this.label25.Text = "Mã tỉnh";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(45, 191);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 13);
            this.label24.TabIndex = 445;
            this.label24.Text = "- Năm lớp 12:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(45, 165);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 13);
            this.label23.TabIndex = 444;
            this.label23.Text = "- Năm lớp 11:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(45, 136);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 13);
            this.label22.TabIndex = 443;
            this.label22.Text = "- Năm lớp 10:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(18, 114);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(215, 13);
            this.label21.TabIndex = 442;
            this.label21.Text = "Nơi học và tốt nghiệp THPT (ghi tên trường)";
            // 
            // btTiepTuc
            // 
            this.btTiepTuc.Location = new System.Drawing.Point(480, 412);
            this.btTiepTuc.Name = "btTiepTuc";
            this.btTiepTuc.Size = new System.Drawing.Size(95, 31);
            this.btTiepTuc.TabIndex = 458;
            this.btTiepTuc.Text = "TIẾP TỤC";
            this.btTiepTuc.UseVisualStyleBackColor = true;
            this.btTiepTuc.Click += new System.EventHandler(this.btTiepTuc_Click);
            // 
            // btTroLai
            // 
            this.btTroLai.Location = new System.Drawing.Point(379, 412);
            this.btTroLai.Name = "btTroLai";
            this.btTroLai.Size = new System.Drawing.Size(95, 31);
            this.btTroLai.TabIndex = 457;
            this.btTroLai.Text = "TRỞ LẠI ";
            this.btTroLai.UseVisualStyleBackColor = true;
            this.btTroLai.Click += new System.EventHandler(this.btTroLai_Click);
            // 
            // btChon1
            // 
            this.btChon1.Location = new System.Drawing.Point(48, 367);
            this.btChon1.Name = "btChon1";
            this.btChon1.Size = new System.Drawing.Size(75, 23);
            this.btChon1.TabIndex = 459;
            this.btChon1.Text = "CHỌN";
            this.btChon1.UseVisualStyleBackColor = true;
            this.btChon1.Click += new System.EventHandler(this.btChon1_Click);
            // 
            // btChon2
            // 
            this.btChon2.Location = new System.Drawing.Point(239, 367);
            this.btChon2.Name = "btChon2";
            this.btChon2.Size = new System.Drawing.Size(75, 23);
            this.btChon2.TabIndex = 460;
            this.btChon2.Text = "CHỌN";
            this.btChon2.UseVisualStyleBackColor = true;
            this.btChon2.Click += new System.EventHandler(this.btChon2_Click);
            // 
            // btChon3
            // 
            this.btChon3.Location = new System.Drawing.Point(427, 367);
            this.btChon3.Name = "btChon3";
            this.btChon3.Size = new System.Drawing.Size(75, 23);
            this.btChon3.TabIndex = 461;
            this.btChon3.Text = "CHỌN";
            this.btChon3.UseVisualStyleBackColor = true;
            this.btChon3.Click += new System.EventHandler(this.btChon3_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "THPT Nguyễn Trãi ",
            "THPT Văn Lang",
            "THPT Lê Quý Đôn",
            "THPT Tân Kỳ 3",
            "THPT Phan Bội Châu",
            "THPT Lương Thế Vinh",
            "THPT Trị An"});
            this.comboBox1.Location = new System.Drawing.Point(121, 133);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(231, 21);
            this.comboBox1.TabIndex = 462;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "THPT Nguyễn Trãi ",
            "THPT Văn Lang",
            "THPT Lê Quý Đôn",
            "THPT Tân Kỳ 3",
            "THPT Phan Bội Châu",
            "THPT Lương Thế Vinh",
            "THPT Trị An"});
            this.comboBox2.Location = new System.Drawing.Point(121, 188);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(231, 21);
            this.comboBox2.TabIndex = 463;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "THPT Nguyễn Trãi ",
            "THPT Văn Lang",
            "THPT Lê Quý Đôn",
            "THPT Tân Kỳ 3",
            "THPT Phan Bội Châu",
            "THPT Lương Thế Vinh",
            "THPT Trị An"});
            this.comboBox3.Location = new System.Drawing.Point(121, 162);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(231, 21);
            this.comboBox3.TabIndex = 464;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "45",
            "01",
            "03",
            "29",
            "63",
            "02",
            "48"});
            this.comboBox4.Location = new System.Drawing.Point(379, 133);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(88, 21);
            this.comboBox4.TabIndex = 465;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "45",
            "01",
            "03",
            "29",
            "63",
            "02",
            "48"});
            this.comboBox5.Location = new System.Drawing.Point(379, 187);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(88, 21);
            this.comboBox5.TabIndex = 466;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "45",
            "01",
            "03",
            "29",
            "63",
            "02",
            "48"});
            this.comboBox6.Location = new System.Drawing.Point(379, 160);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(88, 21);
            this.comboBox6.TabIndex = 467;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "001",
            "284",
            "028",
            "047",
            "014",
            "005",
            "036"});
            this.comboBox7.Location = new System.Drawing.Point(487, 160);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(88, 21);
            this.comboBox7.TabIndex = 470;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "001",
            "284",
            "028",
            "047",
            "014",
            "005",
            "036"});
            this.comboBox8.Location = new System.Drawing.Point(487, 187);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(88, 21);
            this.comboBox8.TabIndex = 469;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "001",
            "284",
            "028",
            "047",
            "014",
            "005",
            "036"});
            this.comboBox9.Location = new System.Drawing.Point(487, 133);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(88, 21);
            this.comboBox9.TabIndex = 468;
            // 
            // ptbVanBang
            // 
            this.ptbVanBang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ptbVanBang.Location = new System.Drawing.Point(400, 243);
            this.ptbVanBang.Name = "ptbVanBang";
            this.ptbVanBang.Size = new System.Drawing.Size(139, 118);
            this.ptbVanBang.TabIndex = 399;
            this.ptbVanBang.TabStop = false;
            // 
            // ptbHinh
            // 
            this.ptbHinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ptbHinh.Location = new System.Drawing.Point(209, 243);
            this.ptbHinh.Name = "ptbHinh";
            this.ptbHinh.Size = new System.Drawing.Size(143, 118);
            this.ptbHinh.TabIndex = 398;
            this.ptbHinh.TabStop = false;
            // 
            // ptbHocBa
            // 
            this.ptbHocBa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ptbHocBa.ErrorImage = null;
            this.ptbHocBa.Location = new System.Drawing.Point(25, 243);
            this.ptbHocBa.Name = "ptbHocBa";
            this.ptbHocBa.Size = new System.Drawing.Size(139, 118);
            this.ptbHocBa.TabIndex = 397;
            this.ptbHocBa.TabStop = false;
            // 
            // fThongtin2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(587, 455);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.comboBox9);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btChon3);
            this.Controls.Add(this.btChon2);
            this.Controls.Add(this.btChon1);
            this.Controls.Add(this.btTiepTuc);
            this.Controls.Add(this.btTroLai);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.ptbVanBang);
            this.Controls.Add(this.ptbHinh);
            this.Controls.Add(this.ptbHocBa);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.cbbKhoi_XT2);
            this.Controls.Add(this.cbbKhoi_XT1);
            this.Controls.Add(this.cbbNguyenVong2);
            this.Controls.Add(this.cbbNguyenVong1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(603, 494);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(603, 494);
            this.Name = "fThongtin2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fThongtin2";
            this.Load += new System.EventHandler(this.fThongtin2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptbVanBang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbHinh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbHocBa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbKhoi_XT2;
        private System.Windows.Forms.ComboBox cbbKhoi_XT1;
        private System.Windows.Forms.ComboBox cbbNguyenVong2;
        private System.Windows.Forms.ComboBox cbbNguyenVong1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox ptbVanBang;
        private System.Windows.Forms.PictureBox ptbHinh;
        private System.Windows.Forms.PictureBox ptbHocBa;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btTiepTuc;
        private System.Windows.Forms.Button btTroLai;
        private System.Windows.Forms.Button btChon1;
        private System.Windows.Forms.Button btChon2;
        private System.Windows.Forms.Button btChon3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox9;
    }
}