﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoDucHoa
{
    public partial class fGioithieu : Form
    {
        

        public fGioithieu()
        {
            InitializeComponent();
        }

        private void btnQuanly_Click(object sender, EventArgs e)
        {
            fLogin login = new fLogin();
            login.Show();
            this.Close();
        }

        private void btnDangkyxettuyen_Click(object sender, EventArgs e)
        {
            fThongtin1 tt_canhan1 = new fThongtin1();
            this.Hide();
            tt_canhan1.Show();
        }

        private void fGioithieu_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Application.Exit();
        }
    }
}
