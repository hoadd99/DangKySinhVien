﻿namespace DoDucHoa
{
    partial class fThongtin3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbVanHocQG = new System.Windows.Forms.TextBox();
            this.txbAnhVanQG = new System.Windows.Forms.TextBox();
            this.txbSinhHocQG = new System.Windows.Forms.TextBox();
            this.txbHoaHocQG = new System.Windows.Forms.TextBox();
            this.txbVatLyQG = new System.Windows.Forms.TextBox();
            this.txbHanhKiemQG = new System.Windows.Forms.TextBox();
            this.txbToanQG = new System.Windows.Forms.TextBox();
            this.txbHanhKiem11 = new System.Windows.Forms.TextBox();
            this.txbToan10 = new System.Windows.Forms.TextBox();
            this.txbToan11 = new System.Windows.Forms.TextBox();
            this.txbVanHoc10 = new System.Windows.Forms.TextBox();
            this.txbAnhVan10 = new System.Windows.Forms.TextBox();
            this.txbSinhHoc10 = new System.Windows.Forms.TextBox();
            this.txbHoaHoc10 = new System.Windows.Forms.TextBox();
            this.txbVanHoc11 = new System.Windows.Forms.TextBox();
            this.txbHanhKiem10 = new System.Windows.Forms.TextBox();
            this.txbVatLy12 = new System.Windows.Forms.TextBox();
            this.txbHoaHoc12 = new System.Windows.Forms.TextBox();
            this.txbToan12 = new System.Windows.Forms.TextBox();
            this.txbSinhHoc12 = new System.Windows.Forms.TextBox();
            this.txbAnhVan12 = new System.Windows.Forms.TextBox();
            this.txbHanhKiem12 = new System.Windows.Forms.TextBox();
            this.txbVatLy11 = new System.Windows.Forms.TextBox();
            this.txbVanHoc12 = new System.Windows.Forms.TextBox();
            this.txbAnhVan11 = new System.Windows.Forms.TextBox();
            this.txbHoaHoc11 = new System.Windows.Forms.TextBox();
            this.txbSinhHoc11 = new System.Windows.Forms.TextBox();
            this.txbVatLy10 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.btTroLai = new System.Windows.Forms.Button();
            this.btDangKi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txbVanHocQG
            // 
            this.txbVanHocQG.Location = new System.Drawing.Point(531, 223);
            this.txbVanHocQG.Name = "txbVanHocQG";
            this.txbVanHocQG.Size = new System.Drawing.Size(93, 20);
            this.txbVanHocQG.TabIndex = 426;
            // 
            // txbAnhVanQG
            // 
            this.txbAnhVanQG.Location = new System.Drawing.Point(531, 197);
            this.txbAnhVanQG.Name = "txbAnhVanQG";
            this.txbAnhVanQG.Size = new System.Drawing.Size(93, 20);
            this.txbAnhVanQG.TabIndex = 425;
            // 
            // txbSinhHocQG
            // 
            this.txbSinhHocQG.Location = new System.Drawing.Point(531, 171);
            this.txbSinhHocQG.Name = "txbSinhHocQG";
            this.txbSinhHocQG.Size = new System.Drawing.Size(93, 20);
            this.txbSinhHocQG.TabIndex = 424;
            // 
            // txbHoaHocQG
            // 
            this.txbHoaHocQG.Location = new System.Drawing.Point(531, 145);
            this.txbHoaHocQG.Name = "txbHoaHocQG";
            this.txbHoaHocQG.Size = new System.Drawing.Size(93, 20);
            this.txbHoaHocQG.TabIndex = 423;
            // 
            // txbVatLyQG
            // 
            this.txbVatLyQG.Location = new System.Drawing.Point(531, 119);
            this.txbVatLyQG.Name = "txbVatLyQG";
            this.txbVatLyQG.Size = new System.Drawing.Size(93, 20);
            this.txbVatLyQG.TabIndex = 422;
            // 
            // txbHanhKiemQG
            // 
            this.txbHanhKiemQG.Location = new System.Drawing.Point(531, 249);
            this.txbHanhKiemQG.Name = "txbHanhKiemQG";
            this.txbHanhKiemQG.Size = new System.Drawing.Size(93, 20);
            this.txbHanhKiemQG.TabIndex = 421;
            // 
            // txbToanQG
            // 
            this.txbToanQG.Location = new System.Drawing.Point(531, 93);
            this.txbToanQG.Name = "txbToanQG";
            this.txbToanQG.Size = new System.Drawing.Size(93, 20);
            this.txbToanQG.TabIndex = 420;
            // 
            // txbHanhKiem11
            // 
            this.txbHanhKiem11.Location = new System.Drawing.Point(255, 249);
            this.txbHanhKiem11.Name = "txbHanhKiem11";
            this.txbHanhKiem11.Size = new System.Drawing.Size(72, 20);
            this.txbHanhKiem11.TabIndex = 419;
            // 
            // txbToan10
            // 
            this.txbToan10.Location = new System.Drawing.Point(125, 93);
            this.txbToan10.Name = "txbToan10";
            this.txbToan10.Size = new System.Drawing.Size(72, 20);
            this.txbToan10.TabIndex = 418;
            // 
            // txbToan11
            // 
            this.txbToan11.Location = new System.Drawing.Point(255, 93);
            this.txbToan11.Name = "txbToan11";
            this.txbToan11.Size = new System.Drawing.Size(72, 20);
            this.txbToan11.TabIndex = 417;
            // 
            // txbVanHoc10
            // 
            this.txbVanHoc10.Location = new System.Drawing.Point(125, 223);
            this.txbVanHoc10.Name = "txbVanHoc10";
            this.txbVanHoc10.Size = new System.Drawing.Size(72, 20);
            this.txbVanHoc10.TabIndex = 416;
            // 
            // txbAnhVan10
            // 
            this.txbAnhVan10.Location = new System.Drawing.Point(125, 197);
            this.txbAnhVan10.Name = "txbAnhVan10";
            this.txbAnhVan10.Size = new System.Drawing.Size(72, 20);
            this.txbAnhVan10.TabIndex = 415;
            // 
            // txbSinhHoc10
            // 
            this.txbSinhHoc10.Location = new System.Drawing.Point(125, 171);
            this.txbSinhHoc10.Name = "txbSinhHoc10";
            this.txbSinhHoc10.Size = new System.Drawing.Size(72, 20);
            this.txbSinhHoc10.TabIndex = 414;
            // 
            // txbHoaHoc10
            // 
            this.txbHoaHoc10.Location = new System.Drawing.Point(125, 145);
            this.txbHoaHoc10.Name = "txbHoaHoc10";
            this.txbHoaHoc10.Size = new System.Drawing.Size(72, 20);
            this.txbHoaHoc10.TabIndex = 413;
            // 
            // txbVanHoc11
            // 
            this.txbVanHoc11.Location = new System.Drawing.Point(255, 223);
            this.txbVanHoc11.Name = "txbVanHoc11";
            this.txbVanHoc11.Size = new System.Drawing.Size(72, 20);
            this.txbVanHoc11.TabIndex = 412;
            // 
            // txbHanhKiem10
            // 
            this.txbHanhKiem10.Location = new System.Drawing.Point(125, 249);
            this.txbHanhKiem10.Name = "txbHanhKiem10";
            this.txbHanhKiem10.Size = new System.Drawing.Size(72, 20);
            this.txbHanhKiem10.TabIndex = 411;
            // 
            // txbVatLy12
            // 
            this.txbVatLy12.Location = new System.Drawing.Point(392, 117);
            this.txbVatLy12.Name = "txbVatLy12";
            this.txbVatLy12.Size = new System.Drawing.Size(76, 20);
            this.txbVatLy12.TabIndex = 410;
            // 
            // txbHoaHoc12
            // 
            this.txbHoaHoc12.Location = new System.Drawing.Point(392, 143);
            this.txbHoaHoc12.Name = "txbHoaHoc12";
            this.txbHoaHoc12.Size = new System.Drawing.Size(76, 20);
            this.txbHoaHoc12.TabIndex = 409;
            // 
            // txbToan12
            // 
            this.txbToan12.Location = new System.Drawing.Point(392, 91);
            this.txbToan12.Name = "txbToan12";
            this.txbToan12.Size = new System.Drawing.Size(76, 20);
            this.txbToan12.TabIndex = 408;
            // 
            // txbSinhHoc12
            // 
            this.txbSinhHoc12.Location = new System.Drawing.Point(392, 169);
            this.txbSinhHoc12.Name = "txbSinhHoc12";
            this.txbSinhHoc12.Size = new System.Drawing.Size(76, 20);
            this.txbSinhHoc12.TabIndex = 407;
            // 
            // txbAnhVan12
            // 
            this.txbAnhVan12.Location = new System.Drawing.Point(392, 195);
            this.txbAnhVan12.Name = "txbAnhVan12";
            this.txbAnhVan12.Size = new System.Drawing.Size(76, 20);
            this.txbAnhVan12.TabIndex = 406;
            // 
            // txbHanhKiem12
            // 
            this.txbHanhKiem12.Location = new System.Drawing.Point(392, 247);
            this.txbHanhKiem12.Name = "txbHanhKiem12";
            this.txbHanhKiem12.Size = new System.Drawing.Size(76, 20);
            this.txbHanhKiem12.TabIndex = 405;
            // 
            // txbVatLy11
            // 
            this.txbVatLy11.Location = new System.Drawing.Point(255, 119);
            this.txbVatLy11.Name = "txbVatLy11";
            this.txbVatLy11.Size = new System.Drawing.Size(72, 20);
            this.txbVatLy11.TabIndex = 404;
            // 
            // txbVanHoc12
            // 
            this.txbVanHoc12.Location = new System.Drawing.Point(392, 221);
            this.txbVanHoc12.Name = "txbVanHoc12";
            this.txbVanHoc12.Size = new System.Drawing.Size(76, 20);
            this.txbVanHoc12.TabIndex = 403;
            // 
            // txbAnhVan11
            // 
            this.txbAnhVan11.Location = new System.Drawing.Point(255, 197);
            this.txbAnhVan11.Name = "txbAnhVan11";
            this.txbAnhVan11.Size = new System.Drawing.Size(72, 20);
            this.txbAnhVan11.TabIndex = 402;
            // 
            // txbHoaHoc11
            // 
            this.txbHoaHoc11.Location = new System.Drawing.Point(255, 145);
            this.txbHoaHoc11.Name = "txbHoaHoc11";
            this.txbHoaHoc11.Size = new System.Drawing.Size(72, 20);
            this.txbHoaHoc11.TabIndex = 401;
            // 
            // txbSinhHoc11
            // 
            this.txbSinhHoc11.Location = new System.Drawing.Point(255, 171);
            this.txbSinhHoc11.Name = "txbSinhHoc11";
            this.txbSinhHoc11.Size = new System.Drawing.Size(72, 20);
            this.txbSinhHoc11.TabIndex = 400;
            // 
            // txbVatLy10
            // 
            this.txbVatLy10.Location = new System.Drawing.Point(125, 119);
            this.txbVatLy10.Name = "txbVatLy10";
            this.txbVatLy10.Size = new System.Drawing.Size(72, 20);
            this.txbVatLy10.TabIndex = 399;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(528, 73);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(96, 13);
            this.label45.TabIndex = 398;
            this.label45.Text = "Điểm thi THPT QG";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(389, 73);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(79, 13);
            this.label44.TabIndex = 397;
            this.label44.Text = "Học kì 1 lớp 12";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(252, 73);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(75, 13);
            this.label43.TabIndex = 396;
            this.label43.Text = "Cả năm lớp 11";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(122, 73);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 13);
            this.label42.TabIndex = 395;
            this.label42.Text = "Cả năm lớp 10";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(25, 73);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 13);
            this.label41.TabIndex = 394;
            this.label41.Text = "Môn học";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(42, 97);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(32, 13);
            this.label40.TabIndex = 393;
            this.label40.Text = "Toán";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(41, 123);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(33, 13);
            this.label39.TabIndex = 392;
            this.label39.Text = "Vật lý";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(26, 149);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(48, 13);
            this.label38.TabIndex = 391;
            this.label38.Text = "Hóa học";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(22, 175);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(52, 13);
            this.label37.TabIndex = 390;
            this.label37.Text = "Sinh học ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(24, 201);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(50, 13);
            this.label36.TabIndex = 389;
            this.label36.Text = "Anh văn ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(30, 227);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 13);
            this.label35.TabIndex = 388;
            this.label35.Text = "Văn học";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(19, 253);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(58, 13);
            this.label34.TabIndex = 387;
            this.label34.Text = "Hạnh kiểm";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(76, 32);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(481, 13);
            this.label33.TabIndex = 428;
            this.label33.Text = "(Lưu ý: Thí sinh chỉ ghi kết quả học tập 3 môn cao điểm nhất tương ứng với khối đ" +
    "ăng ký xét tuyển.)";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(148, 9);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(333, 13);
            this.label32.TabIndex = 427;
            this.label32.Text = "Kết quả học tập(Điểm trung bình cả năm và hạnh kiểm các năm học)";
            // 
            // btTroLai
            // 
            this.btTroLai.Location = new System.Drawing.Point(430, 286);
            this.btTroLai.Name = "btTroLai";
            this.btTroLai.Size = new System.Drawing.Size(95, 31);
            this.btTroLai.TabIndex = 429;
            this.btTroLai.Text = "TRỞ LẠI ";
            this.btTroLai.UseVisualStyleBackColor = true;
            this.btTroLai.Click += new System.EventHandler(this.btTroLai_Click);
            // 
            // btDangKi
            // 
            this.btDangKi.Location = new System.Drawing.Point(531, 286);
            this.btDangKi.Name = "btDangKi";
            this.btDangKi.Size = new System.Drawing.Size(95, 31);
            this.btDangKi.TabIndex = 430;
            this.btDangKi.Text = "ĐĂNG KÍ";
            this.btDangKi.UseVisualStyleBackColor = true;
            this.btDangKi.Click += new System.EventHandler(this.btDangKi_Click);
            // 
            // fThongtin3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(648, 329);
            this.Controls.Add(this.btDangKi);
            this.Controls.Add(this.btTroLai);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.txbVanHocQG);
            this.Controls.Add(this.txbAnhVanQG);
            this.Controls.Add(this.txbSinhHocQG);
            this.Controls.Add(this.txbHoaHocQG);
            this.Controls.Add(this.txbVatLyQG);
            this.Controls.Add(this.txbHanhKiemQG);
            this.Controls.Add(this.txbToanQG);
            this.Controls.Add(this.txbHanhKiem11);
            this.Controls.Add(this.txbToan10);
            this.Controls.Add(this.txbToan11);
            this.Controls.Add(this.txbVanHoc10);
            this.Controls.Add(this.txbAnhVan10);
            this.Controls.Add(this.txbSinhHoc10);
            this.Controls.Add(this.txbHoaHoc10);
            this.Controls.Add(this.txbVanHoc11);
            this.Controls.Add(this.txbHanhKiem10);
            this.Controls.Add(this.txbVatLy12);
            this.Controls.Add(this.txbHoaHoc12);
            this.Controls.Add(this.txbToan12);
            this.Controls.Add(this.txbSinhHoc12);
            this.Controls.Add(this.txbAnhVan12);
            this.Controls.Add(this.txbHanhKiem12);
            this.Controls.Add(this.txbVatLy11);
            this.Controls.Add(this.txbVanHoc12);
            this.Controls.Add(this.txbAnhVan11);
            this.Controls.Add(this.txbHoaHoc11);
            this.Controls.Add(this.txbSinhHoc11);
            this.Controls.Add(this.txbVatLy10);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(664, 368);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(664, 368);
            this.Name = "fThongtin3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fThongtin3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbVanHocQG;
        private System.Windows.Forms.TextBox txbAnhVanQG;
        private System.Windows.Forms.TextBox txbSinhHocQG;
        private System.Windows.Forms.TextBox txbHoaHocQG;
        private System.Windows.Forms.TextBox txbVatLyQG;
        private System.Windows.Forms.TextBox txbHanhKiemQG;
        private System.Windows.Forms.TextBox txbToanQG;
        private System.Windows.Forms.TextBox txbHanhKiem11;
        private System.Windows.Forms.TextBox txbToan10;
        private System.Windows.Forms.TextBox txbToan11;
        private System.Windows.Forms.TextBox txbVanHoc10;
        private System.Windows.Forms.TextBox txbAnhVan10;
        private System.Windows.Forms.TextBox txbSinhHoc10;
        private System.Windows.Forms.TextBox txbHoaHoc10;
        private System.Windows.Forms.TextBox txbVanHoc11;
        private System.Windows.Forms.TextBox txbHanhKiem10;
        private System.Windows.Forms.TextBox txbVatLy12;
        private System.Windows.Forms.TextBox txbHoaHoc12;
        private System.Windows.Forms.TextBox txbToan12;
        private System.Windows.Forms.TextBox txbSinhHoc12;
        private System.Windows.Forms.TextBox txbAnhVan12;
        private System.Windows.Forms.TextBox txbHanhKiem12;
        private System.Windows.Forms.TextBox txbVatLy11;
        private System.Windows.Forms.TextBox txbVanHoc12;
        private System.Windows.Forms.TextBox txbAnhVan11;
        private System.Windows.Forms.TextBox txbHoaHoc11;
        private System.Windows.Forms.TextBox txbSinhHoc11;
        private System.Windows.Forms.TextBox txbVatLy10;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button btTroLai;
        private System.Windows.Forms.Button btDangKi;
    }
}