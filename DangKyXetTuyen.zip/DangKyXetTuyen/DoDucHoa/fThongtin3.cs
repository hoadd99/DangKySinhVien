﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoDucHoa
{
    public partial class fThongtin3 : Form
    {
        public fThongtin3()
        {
            InitializeComponent();
            
        }

        private void btDangKi_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QEN4LJI\MSSQLSERVER1;Initial Catalog=Quanlydangky;Integrated Security=True");
            conn.Open();
            int lop10 = 10;

            string Toan = "toan";
            string ly = "vatly";
            string hoa = "hoahoc";
            string sinh = "sinhhoc";
            string anh = "anhvan";
            string van = "vanhoc";
            string qg = "quocgia";
                            //lấy kiểu chuỗi '"text"'
            string sqlcomandt = "insert into ketqua values (" + lop10 + ",'" + Toan + "'," + txbToan10.Text + ",'" + txbHanhKiem10.Text + "')";
            string sqlcomandl = "insert into ketqua values (" + lop10 + ",'" + ly + "'," + txbVatLy10.Text + ",'" + txbHanhKiem10.Text + "')";
            string sqlcomandh = "insert into ketqua values (" + lop10 + ",'" + hoa + "'," + txbHoaHoc10.Text + ",'" + txbHanhKiem10.Text + "')";
            string sqlcomands = "insert into ketqua values (" + lop10 + ",'" + sinh + "'," + txbSinhHoc10.Text + ",'" + txbHanhKiem10.Text + "')";
            string sqlcomanda = "insert into ketqua values (" + lop10 + ",'" + anh + "'," + txbAnhVan10.Text + ",'" + txbHanhKiem10.Text + "')";
            string sqlcomandv = "insert into ketqua values (" + lop10 + ",'" + van + "'," + txbVanHoc10.Text + ",'" + txbHanhKiem10.Text + "')";

            SqlCommand cmd10t = new SqlCommand(sqlcomandt, conn);
            SqlCommand cmd10l = new SqlCommand(sqlcomandl, conn);
            SqlCommand cmd10h = new SqlCommand(sqlcomandh, conn);
            SqlCommand cmd10s = new SqlCommand(sqlcomands, conn);
            SqlCommand cmd10a = new SqlCommand(sqlcomanda, conn);
            SqlCommand cmd10v = new SqlCommand(sqlcomandv, conn);

            string sqlcomandtqg = "insert into diemquocgia values ('" + qg + "'," + txbToanQG.Text + ",'" + txbHanhKiemQG.Text + "')";
            string sqlcomandlqg = "insert into diemquocgia values ('" + qg + "',"+ txbVatLyQG.Text + ",'" + txbHanhKiemQG.Text + "')";
            string sqlcomandhqg = "insert into diemquocgia values ('" + qg + "'," + txbHoaHocQG.Text + ",'" + txbHanhKiemQG.Text + "')";
            string sqlcomandsqg = "insert into diemquocgia values ('" + qg + "'," + txbSinhHocQG.Text + ",'" + txbHanhKiemQG.Text + "')";
            string sqlcomandaqg = "insert into diemquocgia values ('" + qg + "'," + txbAnhVanQG.Text + ",'" + txbHanhKiemQG.Text + "')";
            string sqlcomandvqg = "insert into diemquocgia values ('" + qg + "'," + txbVanHocQG.Text + ",'" + txbHanhKiemQG.Text + "')";

            SqlCommand cmdqgt = new SqlCommand(sqlcomandtqg, conn);
            SqlCommand cmdqgl = new SqlCommand(sqlcomandlqg, conn);
            SqlCommand cmdqgh = new SqlCommand(sqlcomandhqg, conn);
            SqlCommand cmdqgs = new SqlCommand(sqlcomandsqg, conn);
            SqlCommand cmdqga = new SqlCommand(sqlcomandaqg, conn);
            SqlCommand cmdqgv = new SqlCommand(sqlcomandvqg, conn);


            cmd10t.ExecuteNonQuery();
            cmd10l.ExecuteNonQuery();
            cmd10h.ExecuteNonQuery();
            cmd10s.ExecuteNonQuery();
            cmd10a.ExecuteNonQuery();
            cmd10v.ExecuteNonQuery();

            cmdqgt.ExecuteNonQuery();
            cmdqgl.ExecuteNonQuery();
            cmdqgh.ExecuteNonQuery();
            cmdqgs.ExecuteNonQuery();
            cmdqga.ExecuteNonQuery();
            cmdqgv.ExecuteNonQuery();
            conn.Close();
        }

        private void btTroLai_Click(object sender, EventArgs e)
        {
            fThongtin2 tt2 = new fThongtin2();
            tt2.Show();
            this.Close();
        }
    }
}
