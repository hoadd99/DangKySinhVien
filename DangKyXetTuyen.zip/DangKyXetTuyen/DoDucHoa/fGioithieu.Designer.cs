﻿namespace DoDucHoa
{
    partial class fGioithieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnDangkyAdmission = new System.Windows.Forms.Button();
            this.btnManage = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(223, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "BỘ CÔNG THƯƠNG";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(139, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(354, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "TRƯỜNG CAO ĐẲNG CÔNG THƯƠNG TP.HCM";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(236, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Mã trường: CES";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(51, 138);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(416, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "PHIẾU ĐĂNG KÝ XÉT TUYỂN CAO ĐẲNG CHÍNH QUY 2020";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(89, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(316, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "(Xin vui lòng điền đầy đủ thông tin bằng tiếng việt có dấu)";
            // 
            // btnDangkyAdmission
            // 
            this.btnDangkyAdmission.Location = new System.Drawing.Point(278, 190);
            this.btnDangkyAdmission.Name = "btnDangkyAdmission";
            this.btnDangkyAdmission.Size = new System.Drawing.Size(115, 35);
            this.btnDangkyAdmission.TabIndex = 213;
            this.btnDangkyAdmission.Text = "Đăng ký xét tuyển";
            this.btnDangkyAdmission.UseVisualStyleBackColor = true;
            this.btnDangkyAdmission.Click += new System.EventHandler(this.btnDangkyxettuyen_Click);
            // 
            // btnManage
            // 
            this.btnManage.Location = new System.Drawing.Point(98, 190);
            this.btnManage.Name = "btnManage";
            this.btnManage.Size = new System.Drawing.Size(115, 35);
            this.btnManage.TabIndex = 212;
            this.btnManage.Text = "Quản lý ";
            this.btnManage.UseVisualStyleBackColor = true;
            this.btnManage.Click += new System.EventHandler(this.btnQuanly_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DoDucHoa.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 106);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // fGioithieu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(505, 244);
            this.Controls.Add(this.btnDangkyAdmission);
            this.Controls.Add(this.btnManage);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(521, 283);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(521, 283);
            this.Name = "fGioithieu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GIỚI THIỆU & CHỌN CHỨC NĂNG";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.fGioithieu_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnDangkyAdmission;
        private System.Windows.Forms.Button btnManage;
    }
}

