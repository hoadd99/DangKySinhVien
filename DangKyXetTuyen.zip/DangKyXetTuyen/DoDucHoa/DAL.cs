﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoDucHoa
{
    public class DAL:dbDulieu
    {
        private List<BEL> bELs = new List<BEL>();
    }
}