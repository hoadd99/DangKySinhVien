﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoDucHoa
{
    public partial class fThongtin2 : Form
    {
        public fThongtin2()
        {
            InitializeComponent();
        }

        public fThongtin2(string _valueform1)
        {
            InitializeComponent();
        }

        private void fThongtin2_Load(object sender, EventArgs e)
        {

        }

        private void btTiepTuc_Click(object sender, EventArgs e)
        {
            fThongtin3 f = new fThongtin3();
            this.Hide();
            f.ShowDialog();
        }

        private void btTroLai_Click(object sender, EventArgs e)
        {
            fThongtin1 tt1 = new fThongtin1();
            tt1.Show();
            this.Close();
        }

        private void btChon1_Click(object sender, EventArgs e)
        {
            ptbHocBa.SizeMode = PictureBoxSizeMode.StretchImage;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "JPEG files(*.jpg)|*.jpg";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ptbHocBa.ImageLocation = dlg.FileName;
            }
        }

        private void btChon2_Click(object sender, EventArgs e)
        {
            ptbHinh.SizeMode = PictureBoxSizeMode.StretchImage;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "JPEG files(*.jpg)|*.jpg";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ptbHinh.ImageLocation = dlg.FileName;
            }
        }

        private void btChon3_Click(object sender, EventArgs e)
        {
            ptbVanBang.SizeMode = PictureBoxSizeMode.StretchImage;
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "JPEG files(*.jpg)|*.jpg";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ptbVanBang.ImageLocation = dlg.FileName;
            }
        }
    }
}
