﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DoDucHoa
{
    public class dbDulieu
    {
        
       public SqlConnection CreateConnection()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-QEN4LJI\MSSQLSERVER1;Initial Catalog=Quanlydangky;Integrated Security=True";
            return conn;
        }
    }
}
