﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace DoDucHoa
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
            
        }

        private void btnLog_in_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-QEN4LJI\MSSQLSERVER1;Initial Catalog=Quanlydangky;Integrated Security=True";

            try
            {
                conn.Open();
                string tk = txtAccount.Text;
                string mk = txtPassword.Text;
                string sql = "select*from users where taikhoan='" + tk + "' and matkhau='" + mk + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader data = cmd.ExecuteReader();
                if(/*data.Read()==true*/true)
                {
                    fQuanly ql = new fQuanly();
                    this.Hide();
                    ql.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Tài khoản hoặc mật khẩu không đúng","Thông báo");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi kết nối");
            }
            conn.Close();
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            fGioithieu gt = new fGioithieu();
            this.Hide();
            gt.ShowDialog();
        }

        private void fLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Application.Exit();
        }

        private void fLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
