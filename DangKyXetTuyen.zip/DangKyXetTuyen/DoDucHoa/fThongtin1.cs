﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoDucHoa
{
    public partial class fThongtin1 : Form
    {
        public fThongtin1()
        {
            InitializeComponent();
            
        }

        private void txbCmnd_KeyPress(object sender, KeyPressEventArgs e)
        {
                txbCmnd.MaxLength = 20;
                if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void txbSdt_KeyPress(object sender, KeyPressEventArgs e)
        {
               txbSDT.MaxLength = 11;
               if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                   e.Handled = true;
        }

        private void txbHoten_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void btTiepTuc_Click(object sender, EventArgs e)
        {
            string value = "Hoa";
            fThongtin2 tt_canhan2 = new fThongtin2(value);
            this.Hide();

            tt_canhan2.Show();
            this.Close();

        }

        private void btTroLai_Click(object sender, EventArgs e)
        {
            fGioithieu gt = new fGioithieu();
            gt.Show();
            this.Close();
        }
    }
}
