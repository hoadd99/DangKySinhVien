﻿namespace DoDucHoa
{
    partial class fThongtin1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txbHoTen = new System.Windows.Forms.TextBox();
            this.cbbGioiTinh = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txbCmnd = new System.Windows.Forms.TextBox();
            this.txbNoiCap = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txbHK_ThuongTru = new System.Windows.Forms.TextBox();
            this.cbbKhuVuc = new System.Windows.Forms.ComboBox();
            this.cbbDT_UuTien = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox_Phuongthuc = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txbEmail = new System.Windows.Forms.TextBox();
            this.txbSDT = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txbDC_BaoTin = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.cbbNamSinh = new System.Windows.Forms.ComboBox();
            this.cbbThangSinh = new System.Windows.Forms.ComboBox();
            this.cbbNgaySinh = new System.Windows.Forms.ComboBox();
            this.dtpNgayCap = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btTiepTuc = new System.Windows.Forms.Button();
            this.btTroLai = new System.Windows.Forms.Button();
            this.groupBox_Phuongthuc.SuspendLayout();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(57, 172);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 13);
            this.label15.TabIndex = 182;
            this.label15.Text = "Số CMND";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(58, 145);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 181;
            this.label12.Text = "Sinh ngày";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(261, 13);
            this.label10.TabIndex = 161;
            this.label10.Text = "Họ và tên của thí sinh (viết đúng như  giấy khai sinh):";
            // 
            // txbHoTen
            // 
            this.txbHoTen.Location = new System.Drawing.Point(128, 110);
            this.txbHoTen.Name = "txbHoTen";
            this.txbHoTen.Size = new System.Drawing.Size(444, 20);
            this.txbHoTen.TabIndex = 162;
            this.txbHoTen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbHoten_KeyPress);
            // 
            // cbbGioiTinh
            // 
            this.cbbGioiTinh.FormattingEnabled = true;
            this.cbbGioiTinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cbbGioiTinh.Location = new System.Drawing.Point(452, 141);
            this.cbbGioiTinh.Name = "cbbGioiTinh";
            this.cbbGioiTinh.Size = new System.Drawing.Size(71, 21);
            this.cbbGioiTinh.TabIndex = 163;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(399, 145);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 164;
            this.label11.Text = "Giới tính";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(181, 145);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 165;
            this.label13.Text = "Thàng";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(281, 145);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 13);
            this.label14.TabIndex = 166;
            this.label14.Text = "Năm";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(59, 224);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 13);
            this.label16.TabIndex = 170;
            this.label16.Text = "Ngày cấp";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(68, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 171;
            this.label17.Text = "Nơi cấp";
            // 
            // txbCmnd
            // 
            this.txbCmnd.Location = new System.Drawing.Point(128, 168);
            this.txbCmnd.Name = "txbCmnd";
            this.txbCmnd.Size = new System.Drawing.Size(444, 20);
            this.txbCmnd.TabIndex = 173;
            this.txbCmnd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbCmnd_KeyPress);
            // 
            // txbNoiCap
            // 
            this.txbNoiCap.Location = new System.Drawing.Point(128, 194);
            this.txbNoiCap.Name = "txbNoiCap";
            this.txbNoiCap.Size = new System.Drawing.Size(444, 20);
            this.txbNoiCap.TabIndex = 174;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(13, 302);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(99, 13);
            this.label18.TabIndex = 175;
            this.label18.Text = "Hộ khấu thường trú\r\n";
            // 
            // txbHK_ThuongTru
            // 
            this.txbHK_ThuongTru.Location = new System.Drawing.Point(128, 298);
            this.txbHK_ThuongTru.Name = "txbHK_ThuongTru";
            this.txbHK_ThuongTru.Size = new System.Drawing.Size(444, 20);
            this.txbHK_ThuongTru.TabIndex = 176;
            // 
            // cbbKhuVuc
            // 
            this.cbbKhuVuc.FormattingEnabled = true;
            this.cbbKhuVuc.Items.AddRange(new object[] {
            "KV1",
            "KV2",
            "KV2-NT",
            "KV3"});
            this.cbbKhuVuc.Location = new System.Drawing.Point(424, 269);
            this.cbbKhuVuc.Name = "cbbKhuVuc";
            this.cbbKhuVuc.Size = new System.Drawing.Size(148, 21);
            this.cbbKhuVuc.TabIndex = 180;
            // 
            // cbbDT_UuTien
            // 
            this.cbbDT_UuTien.FormattingEnabled = true;
            this.cbbDT_UuTien.Items.AddRange(new object[] {
            "Đối tượng 01",
            "Đối tượng 02",
            "Đối tượng 03",
            "Đối tượng 04",
            "Đối tượng 05",
            "Đối tượng 06",
            "Đối tượng 07",
            "Không thuộc đối tượng ưu tiên"});
            this.cbbDT_UuTien.Location = new System.Drawing.Point(128, 271);
            this.cbbDT_UuTien.Name = "cbbDT_UuTien";
            this.cbbDT_UuTien.Size = new System.Drawing.Size(207, 21);
            this.cbbDT_UuTien.TabIndex = 179;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(477, 272);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 178;
            this.label20.Text = "Khu vực";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 274);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 13);
            this.label19.TabIndex = 177;
            this.label19.Text = "Đối tượng ưu tiên ";
            // 
            // groupBox_Phuongthuc
            // 
            this.groupBox_Phuongthuc.Controls.Add(this.checkBox2);
            this.groupBox_Phuongthuc.Controls.Add(this.checkBox1);
            this.groupBox_Phuongthuc.Controls.Add(this.label9);
            this.groupBox_Phuongthuc.Location = new System.Drawing.Point(32, 18);
            this.groupBox_Phuongthuc.Name = "groupBox_Phuongthuc";
            this.groupBox_Phuongthuc.Size = new System.Drawing.Size(491, 43);
            this.groupBox_Phuongthuc.TabIndex = 160;
            this.groupBox_Phuongthuc.TabStop = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(321, 20);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(142, 17);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Điểm thi THPT Quốc gia\r\n";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(149, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(148, 17);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Điểm học bạ lớp 10,11,12\r\n";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Theo phương thức:";
            // 
            // txbEmail
            // 
            this.txbEmail.Location = new System.Drawing.Point(353, 324);
            this.txbEmail.Name = "txbEmail";
            this.txbEmail.Size = new System.Drawing.Size(219, 20);
            this.txbEmail.TabIndex = 296;
            // 
            // txbSDT
            // 
            this.txbSDT.Location = new System.Drawing.Point(128, 324);
            this.txbSDT.Name = "txbSDT";
            this.txbSDT.Size = new System.Drawing.Size(147, 20);
            this.txbSDT.TabIndex = 295;
            this.txbSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbSdt_KeyPress);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(319, 327);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(32, 13);
            this.label50.TabIndex = 294;
            this.label50.Text = "Email";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(74, 327);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(38, 13);
            this.label48.TabIndex = 293;
            this.label48.Text = "Số ĐT";
            // 
            // txbDC_BaoTin
            // 
            this.txbDC_BaoTin.Location = new System.Drawing.Point(128, 363);
            this.txbDC_BaoTin.Name = "txbDC_BaoTin";
            this.txbDC_BaoTin.Size = new System.Drawing.Size(444, 20);
            this.txbDC_BaoTin.TabIndex = 300;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(21, 347);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(463, 13);
            this.label51.TabIndex = 299;
            this.label51.Text = "Địa chỉ báo tin: (Ghi rõ số nhà, đường, khu phố, phường/xã, quận/huyện/thị xã, tỉ" +
    "nh/thành phố )";
            // 
            // cbbNamSinh
            // 
            this.cbbNamSinh.FormattingEnabled = true;
            this.cbbNamSinh.Items.AddRange(new object[] {
            "1976",
            "1977",
            "1978",
            "1979",
            "1980",
            "1981",
            "1982",
            "1983",
            "1984",
            "1985",
            "1986",
            "1987",
            "1988",
            "1989",
            "1990",
            "1991",
            "1992",
            "1993",
            "1994",
            "1995",
            "1996",
            "1997",
            "1998",
            "1999",
            "2000",
            "2001",
            "2002",
            "2003"});
            this.cbbNamSinh.Location = new System.Drawing.Point(316, 141);
            this.cbbNamSinh.Name = "cbbNamSinh";
            this.cbbNamSinh.Size = new System.Drawing.Size(77, 21);
            this.cbbNamSinh.TabIndex = 309;
            // 
            // cbbThangSinh
            // 
            this.cbbThangSinh.FormattingEnabled = true;
            this.cbbThangSinh.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cbbThangSinh.Location = new System.Drawing.Point(224, 141);
            this.cbbThangSinh.Name = "cbbThangSinh";
            this.cbbThangSinh.Size = new System.Drawing.Size(51, 21);
            this.cbbThangSinh.TabIndex = 310;
            // 
            // cbbNgaySinh
            // 
            this.cbbNgaySinh.FormattingEnabled = true;
            this.cbbNgaySinh.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cbbNgaySinh.Location = new System.Drawing.Point(128, 141);
            this.cbbNgaySinh.Name = "cbbNgaySinh";
            this.cbbNgaySinh.Size = new System.Drawing.Size(47, 21);
            this.cbbNgaySinh.TabIndex = 311;
            // 
            // dtpNgayCap
            // 
            this.dtpNgayCap.Location = new System.Drawing.Point(128, 220);
            this.dtpNgayCap.Name = "dtpNgayCap";
            this.dtpNgayCap.Size = new System.Drawing.Size(200, 20);
            this.dtpNgayCap.TabIndex = 312;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(376, 274);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 390;
            this.label1.Text = "Khu vực";
            // 
            // btTiepTuc
            // 
            this.btTiepTuc.Location = new System.Drawing.Point(482, 406);
            this.btTiepTuc.Name = "btTiepTuc";
            this.btTiepTuc.Size = new System.Drawing.Size(95, 31);
            this.btTiepTuc.TabIndex = 432;
            this.btTiepTuc.Text = "TIẾP TỤC";
            this.btTiepTuc.UseVisualStyleBackColor = true;
            this.btTiepTuc.Click += new System.EventHandler(this.btTiepTuc_Click);
            // 
            // btTroLai
            // 
            this.btTroLai.Location = new System.Drawing.Point(381, 406);
            this.btTroLai.Name = "btTroLai";
            this.btTroLai.Size = new System.Drawing.Size(95, 31);
            this.btTroLai.TabIndex = 431;
            this.btTroLai.Text = "TRỞ LẠI";
            this.btTroLai.UseVisualStyleBackColor = true;
            this.btTroLai.Click += new System.EventHandler(this.btTroLai_Click);
            // 
            // fThongtin1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(589, 449);
            this.Controls.Add(this.btTiepTuc);
            this.Controls.Add(this.btTroLai);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpNgayCap);
            this.Controls.Add(this.cbbNgaySinh);
            this.Controls.Add(this.cbbThangSinh);
            this.Controls.Add(this.cbbNamSinh);
            this.Controls.Add(this.txbDC_BaoTin);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.txbEmail);
            this.Controls.Add(this.txbSDT);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txbHoTen);
            this.Controls.Add(this.cbbGioiTinh);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txbCmnd);
            this.Controls.Add(this.txbNoiCap);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txbHK_ThuongTru);
            this.Controls.Add(this.cbbKhuVuc);
            this.Controls.Add(this.cbbDT_UuTien);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.groupBox_Phuongthuc);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(605, 488);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(605, 488);
            this.Name = "fThongtin1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÔNG TIN CÁ NHÂN";
            this.groupBox_Phuongthuc.ResumeLayout(false);
            this.groupBox_Phuongthuc.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txbHoTen;
        private System.Windows.Forms.ComboBox cbbGioiTinh;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txbCmnd;
        private System.Windows.Forms.TextBox txbNoiCap;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txbHK_ThuongTru;
        private System.Windows.Forms.ComboBox cbbKhuVuc;
        private System.Windows.Forms.ComboBox cbbDT_UuTien;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox_Phuongthuc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txbEmail;
        private System.Windows.Forms.TextBox txbSDT;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txbDC_BaoTin;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox cbbNamSinh;
        private System.Windows.Forms.ComboBox cbbThangSinh;
        private System.Windows.Forms.ComboBox cbbNgaySinh;
        private System.Windows.Forms.DateTimePicker dtpNgayCap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btTiepTuc;
        private System.Windows.Forms.Button btTroLai;
    }
}